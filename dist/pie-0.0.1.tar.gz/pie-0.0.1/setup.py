from setuptools import setup

setup(
    name='pie',
    version='0.0.1',
    description='',
    long_description='',
    url='https://github.com/JoaoRodrigues/pie',
    author='Joao Rodrigues',
    author_email='j.p.g.l.m.rodrigues@gmail.com',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
